/**
 */
package themepark;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attraction</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link themepark.Attraction#getType <em>Type</em>}</li>
 *   <li>{@link themepark.Attraction#getCategory <em>Category</em>}</li>
 *   <li>{@link themepark.Attraction#getEquipments <em>Equipments</em>}</li>
 *   <li>{@link themepark.Attraction#getCapacity <em>Capacity</em>}</li>
 * </ul>
 *
 * @see themepark.ThemeparkPackage#getAttraction()
 * @model
 * @generated
 */
public interface Attraction extends Named {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link themepark.AttractionType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see themepark.AttractionType
	 * @see #setType(AttractionType)
	 * @see themepark.ThemeparkPackage#getAttraction_Type()
	 * @model
	 * @generated
	 */
	AttractionType getType();

	/**
	 * Sets the value of the '{@link themepark.Attraction#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see themepark.AttractionType
	 * @see #getType()
	 * @generated
	 */
	void setType(AttractionType value);

	/**
	 * Returns the value of the '<em><b>Category</b></em>' attribute.
	 * The literals are from the enumeration {@link themepark.AttractionCategory}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Category</em>' attribute.
	 * @see themepark.AttractionCategory
	 * @see #setCategory(AttractionCategory)
	 * @see themepark.ThemeparkPackage#getAttraction_Category()
	 * @model
	 * @generated
	 */
	AttractionCategory getCategory();

	/**
	 * Sets the value of the '{@link themepark.Attraction#getCategory <em>Category</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Category</em>' attribute.
	 * @see themepark.AttractionCategory
	 * @see #getCategory()
	 * @generated
	 */
	void setCategory(AttractionCategory value);

	/**
	 * Returns the value of the '<em><b>Equipments</b></em>' containment reference list.
	 * The list contents are of type {@link themepark.Equipment}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Equipments</em>' containment reference list.
	 * @see themepark.ThemeparkPackage#getAttraction_Equipments()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Equipment> getEquipments();

	/**
	 * Returns the value of the '<em><b>Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Capacity</em>' attribute.
	 * @see #setCapacity(int)
	 * @see themepark.ThemeparkPackage#getAttraction_Capacity()
	 * @model
	 * @generated
	 */
	int getCapacity();

	/**
	 * Sets the value of the '{@link themepark.Attraction#getCapacity <em>Capacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Capacity</em>' attribute.
	 * @see #getCapacity()
	 * @generated
	 */
	void setCapacity(int value);

} // Attraction
