/**
 */
package themepark;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Green Space</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link themepark.GreenSpace#getArea <em>Area</em>}</li>
 * </ul>
 *
 * @see themepark.ThemeparkPackage#getGreenSpace()
 * @model
 * @generated
 */
public interface GreenSpace extends Named {
	/**
	 * Returns the value of the '<em><b>Area</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Area</em>' attribute.
	 * @see #setArea(float)
	 * @see themepark.ThemeparkPackage#getGreenSpace_Area()
	 * @model
	 * @generated
	 */
	float getArea();

	/**
	 * Sets the value of the '{@link themepark.GreenSpace#getArea <em>Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Area</em>' attribute.
	 * @see #getArea()
	 * @generated
	 */
	void setArea(float value);

} // GreenSpace
