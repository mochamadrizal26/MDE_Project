/**
 */
package themepark.util;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

import themepark.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see themepark.ThemeparkPackage
 * @generated
 */
public class ThemeparkAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static ThemeparkPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ThemeparkAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = ThemeparkPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ThemeparkSwitch<Adapter> modelSwitch =
		new ThemeparkSwitch<Adapter>() {
			@Override
			public Adapter caseThemePark(ThemePark object) {
				return createThemeParkAdapter();
			}
			@Override
			public Adapter caseNamed(Named object) {
				return createNamedAdapter();
			}
			@Override
			public Adapter caseTheme(Theme object) {
				return createThemeAdapter();
			}
			@Override
			public Adapter caseGate(Gate object) {
				return createGateAdapter();
			}
			@Override
			public Adapter caseTransportation(Transportation object) {
				return createTransportationAdapter();
			}
			@Override
			public Adapter caseAttraction(Attraction object) {
				return createAttractionAdapter();
			}
			@Override
			public Adapter caseEquipment(Equipment object) {
				return createEquipmentAdapter();
			}
			@Override
			public Adapter caseFacility(Facility object) {
				return createFacilityAdapter();
			}
			@Override
			public Adapter caseDiningResto(DiningResto object) {
				return createDiningRestoAdapter();
			}
			@Override
			public Adapter caseSouvenirShopping(SouvenirShopping object) {
				return createSouvenirShoppingAdapter();
			}
			@Override
			public Adapter caseFirstAidEmergency(FirstAidEmergency object) {
				return createFirstAidEmergencyAdapter();
			}
			@Override
			public Adapter caseBabyCare(BabyCare object) {
				return createBabyCareAdapter();
			}
			@Override
			public Adapter caseInfoCenterPoint(InfoCenterPoint object) {
				return createInfoCenterPointAdapter();
			}
			@Override
			public Adapter caseToilet(Toilet object) {
				return createToiletAdapter();
			}
			@Override
			public Adapter caseGreenSpace(GreenSpace object) {
				return createGreenSpaceAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link themepark.ThemePark <em>Theme Park</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see themepark.ThemePark
	 * @generated
	 */
	public Adapter createThemeParkAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link themepark.Named <em>Named</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see themepark.Named
	 * @generated
	 */
	public Adapter createNamedAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link themepark.Theme <em>Theme</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see themepark.Theme
	 * @generated
	 */
	public Adapter createThemeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link themepark.Gate <em>Gate</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see themepark.Gate
	 * @generated
	 */
	public Adapter createGateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link themepark.Transportation <em>Transportation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see themepark.Transportation
	 * @generated
	 */
	public Adapter createTransportationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link themepark.Attraction <em>Attraction</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see themepark.Attraction
	 * @generated
	 */
	public Adapter createAttractionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link themepark.Equipment <em>Equipment</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see themepark.Equipment
	 * @generated
	 */
	public Adapter createEquipmentAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link themepark.Facility <em>Facility</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see themepark.Facility
	 * @generated
	 */
	public Adapter createFacilityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link themepark.DiningResto <em>Dining Resto</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see themepark.DiningResto
	 * @generated
	 */
	public Adapter createDiningRestoAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link themepark.SouvenirShopping <em>Souvenir Shopping</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see themepark.SouvenirShopping
	 * @generated
	 */
	public Adapter createSouvenirShoppingAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link themepark.FirstAidEmergency <em>First Aid Emergency</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see themepark.FirstAidEmergency
	 * @generated
	 */
	public Adapter createFirstAidEmergencyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link themepark.BabyCare <em>Baby Care</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see themepark.BabyCare
	 * @generated
	 */
	public Adapter createBabyCareAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link themepark.InfoCenterPoint <em>Info Center Point</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see themepark.InfoCenterPoint
	 * @generated
	 */
	public Adapter createInfoCenterPointAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link themepark.Toilet <em>Toilet</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see themepark.Toilet
	 * @generated
	 */
	public Adapter createToiletAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link themepark.GreenSpace <em>Green Space</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see themepark.GreenSpace
	 * @generated
	 */
	public Adapter createGreenSpaceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //ThemeparkAdapterFactory
