/**
 */
package themepark;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Equipment</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link themepark.Equipment#getCategory <em>Category</em>}</li>
 *   <li>{@link themepark.Equipment#getQuantity <em>Quantity</em>}</li>
 * </ul>
 *
 * @see themepark.ThemeparkPackage#getEquipment()
 * @model
 * @generated
 */
public interface Equipment extends Named {
	/**
	 * Returns the value of the '<em><b>Category</b></em>' attribute.
	 * The literals are from the enumeration {@link themepark.Kit}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Category</em>' attribute.
	 * @see themepark.Kit
	 * @see #setCategory(Kit)
	 * @see themepark.ThemeparkPackage#getEquipment_Category()
	 * @model
	 * @generated
	 */
	Kit getCategory();

	/**
	 * Sets the value of the '{@link themepark.Equipment#getCategory <em>Category</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Category</em>' attribute.
	 * @see themepark.Kit
	 * @see #getCategory()
	 * @generated
	 */
	void setCategory(Kit value);

	/**
	 * Returns the value of the '<em><b>Quantity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Quantity</em>' attribute.
	 * @see #setQuantity(int)
	 * @see themepark.ThemeparkPackage#getEquipment_Quantity()
	 * @model
	 * @generated
	 */
	int getQuantity();

	/**
	 * Sets the value of the '{@link themepark.Equipment#getQuantity <em>Quantity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Quantity</em>' attribute.
	 * @see #getQuantity()
	 * @generated
	 */
	void setQuantity(int value);

} // Equipment
