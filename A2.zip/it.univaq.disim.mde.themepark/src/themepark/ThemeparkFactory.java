/**
 */
package themepark;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see themepark.ThemeparkPackage
 * @generated
 */
public interface ThemeparkFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ThemeparkFactory eINSTANCE = themepark.impl.ThemeparkFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Theme Park</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Theme Park</em>'.
	 * @generated
	 */
	ThemePark createThemePark();

	/**
	 * Returns a new object of class '<em>Named</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Named</em>'.
	 * @generated
	 */
	Named createNamed();

	/**
	 * Returns a new object of class '<em>Theme</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Theme</em>'.
	 * @generated
	 */
	Theme createTheme();

	/**
	 * Returns a new object of class '<em>Gate</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Gate</em>'.
	 * @generated
	 */
	Gate createGate();

	/**
	 * Returns a new object of class '<em>Transportation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Transportation</em>'.
	 * @generated
	 */
	Transportation createTransportation();

	/**
	 * Returns a new object of class '<em>Attraction</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Attraction</em>'.
	 * @generated
	 */
	Attraction createAttraction();

	/**
	 * Returns a new object of class '<em>Equipment</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Equipment</em>'.
	 * @generated
	 */
	Equipment createEquipment();

	/**
	 * Returns a new object of class '<em>Dining Resto</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Dining Resto</em>'.
	 * @generated
	 */
	DiningResto createDiningResto();

	/**
	 * Returns a new object of class '<em>Souvenir Shopping</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Souvenir Shopping</em>'.
	 * @generated
	 */
	SouvenirShopping createSouvenirShopping();

	/**
	 * Returns a new object of class '<em>First Aid Emergency</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>First Aid Emergency</em>'.
	 * @generated
	 */
	FirstAidEmergency createFirstAidEmergency();

	/**
	 * Returns a new object of class '<em>Baby Care</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Baby Care</em>'.
	 * @generated
	 */
	BabyCare createBabyCare();

	/**
	 * Returns a new object of class '<em>Info Center Point</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Info Center Point</em>'.
	 * @generated
	 */
	InfoCenterPoint createInfoCenterPoint();

	/**
	 * Returns a new object of class '<em>Toilet</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Toilet</em>'.
	 * @generated
	 */
	Toilet createToilet();

	/**
	 * Returns a new object of class '<em>Green Space</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Green Space</em>'.
	 * @generated
	 */
	GreenSpace createGreenSpace();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	ThemeparkPackage getThemeparkPackage();

} //ThemeparkFactory
