/**
 */
package themepark;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Theme</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link themepark.Theme#getAttractions <em>Attractions</em>}</li>
 *   <li>{@link themepark.Theme#getFacilities <em>Facilities</em>}</li>
 *   <li>{@link themepark.Theme#getGreenSpaces <em>Green Spaces</em>}</li>
 * </ul>
 *
 * @see themepark.ThemeparkPackage#getTheme()
 * @model
 * @generated
 */
public interface Theme extends Named {
	/**
	 * Returns the value of the '<em><b>Attractions</b></em>' containment reference list.
	 * The list contents are of type {@link themepark.Attraction}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attractions</em>' containment reference list.
	 * @see themepark.ThemeparkPackage#getTheme_Attractions()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Attraction> getAttractions();

	/**
	 * Returns the value of the '<em><b>Facilities</b></em>' containment reference list.
	 * The list contents are of type {@link themepark.Facility}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Facilities</em>' containment reference list.
	 * @see themepark.ThemeparkPackage#getTheme_Facilities()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Facility> getFacilities();

	/**
	 * Returns the value of the '<em><b>Green Spaces</b></em>' reference list.
	 * The list contents are of type {@link themepark.GreenSpace}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Green Spaces</em>' reference list.
	 * @see themepark.ThemeparkPackage#getTheme_GreenSpaces()
	 * @model
	 * @generated
	 */
	EList<GreenSpace> getGreenSpaces();

} // Theme
