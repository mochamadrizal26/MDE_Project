/**
 */
package themepark;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Resto Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see themepark.ThemeparkPackage#getRestoType()
 * @model
 * @generated
 */
public enum RestoType implements Enumerator {
	/**
	 * The '<em><b>General</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #GENERAL_VALUE
	 * @generated
	 * @ordered
	 */
	GENERAL(0, "General", "General"),

	/**
	 * The '<em><b>Western</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #WESTERN_VALUE
	 * @generated
	 * @ordered
	 */
	WESTERN(1, "Western", "Western"),

	/**
	 * The '<em><b>Chinese</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CHINESE_VALUE
	 * @generated
	 * @ordered
	 */
	CHINESE(2, "Chinese", "Chinese"),

	/**
	 * The '<em><b>Indian</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #INDIAN_VALUE
	 * @generated
	 * @ordered
	 */
	INDIAN(3, "Indian", "Indian");

	/**
	 * The '<em><b>General</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #GENERAL
	 * @model name="General"
	 * @generated
	 * @ordered
	 */
	public static final int GENERAL_VALUE = 0;

	/**
	 * The '<em><b>Western</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #WESTERN
	 * @model name="Western"
	 * @generated
	 * @ordered
	 */
	public static final int WESTERN_VALUE = 1;

	/**
	 * The '<em><b>Chinese</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CHINESE
	 * @model name="Chinese"
	 * @generated
	 * @ordered
	 */
	public static final int CHINESE_VALUE = 2;

	/**
	 * The '<em><b>Indian</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #INDIAN
	 * @model name="Indian"
	 * @generated
	 * @ordered
	 */
	public static final int INDIAN_VALUE = 3;

	/**
	 * An array of all the '<em><b>Resto Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final RestoType[] VALUES_ARRAY =
		new RestoType[] {
			GENERAL,
			WESTERN,
			CHINESE,
			INDIAN,
		};

	/**
	 * A public read-only list of all the '<em><b>Resto Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<RestoType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Resto Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static RestoType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			RestoType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Resto Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static RestoType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			RestoType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Resto Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static RestoType get(int value) {
		switch (value) {
			case GENERAL_VALUE: return GENERAL;
			case WESTERN_VALUE: return WESTERN;
			case CHINESE_VALUE: return CHINESE;
			case INDIAN_VALUE: return INDIAN;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private RestoType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //RestoType
