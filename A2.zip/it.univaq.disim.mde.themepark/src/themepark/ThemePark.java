/**
 */
package themepark;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Theme Park</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link themepark.ThemePark#getLocation <em>Location</em>}</li>
 *   <li>{@link themepark.ThemePark#getGates <em>Gates</em>}</li>
 *   <li>{@link themepark.ThemePark#getThemes <em>Themes</em>}</li>
 *   <li>{@link themepark.ThemePark#getTransportations <em>Transportations</em>}</li>
 *   <li>{@link themepark.ThemePark#getGreenSpaces <em>Green Spaces</em>}</li>
 * </ul>
 *
 * @see themepark.ThemeparkPackage#getThemePark()
 * @model
 * @generated
 */
public interface ThemePark extends Named {
	/**
	 * Returns the value of the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Location</em>' attribute.
	 * @see #setLocation(String)
	 * @see themepark.ThemeparkPackage#getThemePark_Location()
	 * @model
	 * @generated
	 */
	String getLocation();

	/**
	 * Sets the value of the '{@link themepark.ThemePark#getLocation <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Location</em>' attribute.
	 * @see #getLocation()
	 * @generated
	 */
	void setLocation(String value);

	/**
	 * Returns the value of the '<em><b>Gates</b></em>' containment reference list.
	 * The list contents are of type {@link themepark.Gate}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Gates</em>' containment reference list.
	 * @see themepark.ThemeparkPackage#getThemePark_Gates()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Gate> getGates();

	/**
	 * Returns the value of the '<em><b>Themes</b></em>' containment reference list.
	 * The list contents are of type {@link themepark.Theme}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Themes</em>' containment reference list.
	 * @see themepark.ThemeparkPackage#getThemePark_Themes()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Theme> getThemes();

	/**
	 * Returns the value of the '<em><b>Transportations</b></em>' containment reference list.
	 * The list contents are of type {@link themepark.Transportation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transportations</em>' containment reference list.
	 * @see themepark.ThemeparkPackage#getThemePark_Transportations()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Transportation> getTransportations();

	/**
	 * Returns the value of the '<em><b>Green Spaces</b></em>' containment reference list.
	 * The list contents are of type {@link themepark.GreenSpace}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Green Spaces</em>' containment reference list.
	 * @see themepark.ThemeparkPackage#getThemePark_GreenSpaces()
	 * @model containment="true"
	 * @generated
	 */
	EList<GreenSpace> getGreenSpaces();

} // ThemePark
