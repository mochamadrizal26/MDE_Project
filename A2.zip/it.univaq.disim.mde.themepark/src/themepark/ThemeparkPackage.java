/**
 */
package themepark;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see themepark.ThemeparkFactory
 * @model kind="package"
 * @generated
 */
public interface ThemeparkPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "themepark";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/themepark";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "themepark";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ThemeparkPackage eINSTANCE = themepark.impl.ThemeparkPackageImpl.init();

	/**
	 * The meta object id for the '{@link themepark.impl.NamedImpl <em>Named</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.impl.NamedImpl
	 * @see themepark.impl.ThemeparkPackageImpl#getNamed()
	 * @generated
	 */
	int NAMED = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED__NAME = 0;

	/**
	 * The number of structural features of the '<em>Named</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Named</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link themepark.impl.ThemeParkImpl <em>Theme Park</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.impl.ThemeParkImpl
	 * @see themepark.impl.ThemeparkPackageImpl#getThemePark()
	 * @generated
	 */
	int THEME_PARK = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEME_PARK__NAME = NAMED__NAME;

	/**
	 * The feature id for the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEME_PARK__LOCATION = NAMED_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Gates</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEME_PARK__GATES = NAMED_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Themes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEME_PARK__THEMES = NAMED_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Transportations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEME_PARK__TRANSPORTATIONS = NAMED_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Green Spaces</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEME_PARK__GREEN_SPACES = NAMED_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Theme Park</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEME_PARK_FEATURE_COUNT = NAMED_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Theme Park</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEME_PARK_OPERATION_COUNT = NAMED_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link themepark.impl.ThemeImpl <em>Theme</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.impl.ThemeImpl
	 * @see themepark.impl.ThemeparkPackageImpl#getTheme()
	 * @generated
	 */
	int THEME = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEME__NAME = NAMED__NAME;

	/**
	 * The feature id for the '<em><b>Attractions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEME__ATTRACTIONS = NAMED_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Facilities</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEME__FACILITIES = NAMED_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Green Spaces</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEME__GREEN_SPACES = NAMED_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Theme</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEME_FEATURE_COUNT = NAMED_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Theme</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THEME_OPERATION_COUNT = NAMED_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link themepark.impl.GateImpl <em>Gate</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.impl.GateImpl
	 * @see themepark.impl.ThemeparkPackageImpl#getGate()
	 * @generated
	 */
	int GATE = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GATE__NAME = NAMED__NAME;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GATE__TYPE = NAMED_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Gate</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GATE_FEATURE_COUNT = NAMED_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Gate</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GATE_OPERATION_COUNT = NAMED_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link themepark.impl.TransportationImpl <em>Transportation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.impl.TransportationImpl
	 * @see themepark.impl.ThemeparkPackageImpl#getTransportation()
	 * @generated
	 */
	int TRANSPORTATION = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORTATION__NAME = NAMED__NAME;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORTATION__TYPE = NAMED_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Category</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORTATION__CATEGORY = NAMED_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Destination</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORTATION__DESTINATION = NAMED_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Transportation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORTATION_FEATURE_COUNT = NAMED_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Transportation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORTATION_OPERATION_COUNT = NAMED_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link themepark.impl.AttractionImpl <em>Attraction</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.impl.AttractionImpl
	 * @see themepark.impl.ThemeparkPackageImpl#getAttraction()
	 * @generated
	 */
	int ATTRACTION = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRACTION__NAME = NAMED__NAME;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRACTION__TYPE = NAMED_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Category</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRACTION__CATEGORY = NAMED_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Equipments</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRACTION__EQUIPMENTS = NAMED_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRACTION__CAPACITY = NAMED_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Attraction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRACTION_FEATURE_COUNT = NAMED_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Attraction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRACTION_OPERATION_COUNT = NAMED_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link themepark.impl.EquipmentImpl <em>Equipment</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.impl.EquipmentImpl
	 * @see themepark.impl.ThemeparkPackageImpl#getEquipment()
	 * @generated
	 */
	int EQUIPMENT = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT__NAME = NAMED__NAME;

	/**
	 * The feature id for the '<em><b>Category</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT__CATEGORY = NAMED_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Quantity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT__QUANTITY = NAMED_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Equipment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT_FEATURE_COUNT = NAMED_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Equipment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPMENT_OPERATION_COUNT = NAMED_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link themepark.impl.FacilityImpl <em>Facility</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.impl.FacilityImpl
	 * @see themepark.impl.ThemeparkPackageImpl#getFacility()
	 * @generated
	 */
	int FACILITY = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FACILITY__NAME = NAMED__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FACILITY__ID = NAMED_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Facility</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FACILITY_FEATURE_COUNT = NAMED_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Facility</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FACILITY_OPERATION_COUNT = NAMED_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link themepark.impl.DiningRestoImpl <em>Dining Resto</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.impl.DiningRestoImpl
	 * @see themepark.impl.ThemeparkPackageImpl#getDiningResto()
	 * @generated
	 */
	int DINING_RESTO = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DINING_RESTO__NAME = FACILITY__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DINING_RESTO__ID = FACILITY__ID;

	/**
	 * The feature id for the '<em><b>Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DINING_RESTO__CAPACITY = FACILITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DINING_RESTO__TYPE = FACILITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Telephone</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DINING_RESTO__TELEPHONE = FACILITY_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Dining Resto</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DINING_RESTO_FEATURE_COUNT = FACILITY_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Dining Resto</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DINING_RESTO_OPERATION_COUNT = FACILITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link themepark.impl.SouvenirShoppingImpl <em>Souvenir Shopping</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.impl.SouvenirShoppingImpl
	 * @see themepark.impl.ThemeparkPackageImpl#getSouvenirShopping()
	 * @generated
	 */
	int SOUVENIR_SHOPPING = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOUVENIR_SHOPPING__NAME = FACILITY__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOUVENIR_SHOPPING__ID = FACILITY__ID;

	/**
	 * The feature id for the '<em><b>Telephone</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOUVENIR_SHOPPING__TELEPHONE = FACILITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Souvenir Shopping</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOUVENIR_SHOPPING_FEATURE_COUNT = FACILITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Souvenir Shopping</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOUVENIR_SHOPPING_OPERATION_COUNT = FACILITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link themepark.impl.FirstAidEmergencyImpl <em>First Aid Emergency</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.impl.FirstAidEmergencyImpl
	 * @see themepark.impl.ThemeparkPackageImpl#getFirstAidEmergency()
	 * @generated
	 */
	int FIRST_AID_EMERGENCY = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIRST_AID_EMERGENCY__NAME = FACILITY__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIRST_AID_EMERGENCY__ID = FACILITY__ID;

	/**
	 * The feature id for the '<em><b>Telephone</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIRST_AID_EMERGENCY__TELEPHONE = FACILITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>First Aid Emergency</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIRST_AID_EMERGENCY_FEATURE_COUNT = FACILITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>First Aid Emergency</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIRST_AID_EMERGENCY_OPERATION_COUNT = FACILITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link themepark.impl.BabyCareImpl <em>Baby Care</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.impl.BabyCareImpl
	 * @see themepark.impl.ThemeparkPackageImpl#getBabyCare()
	 * @generated
	 */
	int BABY_CARE = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BABY_CARE__NAME = FACILITY__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BABY_CARE__ID = FACILITY__ID;

	/**
	 * The feature id for the '<em><b>Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BABY_CARE__CAPACITY = FACILITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Baby Care</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BABY_CARE_FEATURE_COUNT = FACILITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Baby Care</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BABY_CARE_OPERATION_COUNT = FACILITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link themepark.impl.InfoCenterPointImpl <em>Info Center Point</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.impl.InfoCenterPointImpl
	 * @see themepark.impl.ThemeparkPackageImpl#getInfoCenterPoint()
	 * @generated
	 */
	int INFO_CENTER_POINT = 12;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_CENTER_POINT__NAME = FACILITY__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_CENTER_POINT__ID = FACILITY__ID;

	/**
	 * The feature id for the '<em><b>Telephone</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_CENTER_POINT__TELEPHONE = FACILITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Info Center Point</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_CENTER_POINT_FEATURE_COUNT = FACILITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Info Center Point</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_CENTER_POINT_OPERATION_COUNT = FACILITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link themepark.impl.ToiletImpl <em>Toilet</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.impl.ToiletImpl
	 * @see themepark.impl.ThemeparkPackageImpl#getToilet()
	 * @generated
	 */
	int TOILET = 13;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOILET__NAME = FACILITY__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOILET__ID = FACILITY__ID;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOILET__TYPE = FACILITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Toilet</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOILET_FEATURE_COUNT = FACILITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Toilet</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOILET_OPERATION_COUNT = FACILITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link themepark.impl.GreenSpaceImpl <em>Green Space</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.impl.GreenSpaceImpl
	 * @see themepark.impl.ThemeparkPackageImpl#getGreenSpace()
	 * @generated
	 */
	int GREEN_SPACE = 14;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GREEN_SPACE__NAME = NAMED__NAME;

	/**
	 * The feature id for the '<em><b>Area</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GREEN_SPACE__AREA = NAMED_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Green Space</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GREEN_SPACE_FEATURE_COUNT = NAMED_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Green Space</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GREEN_SPACE_OPERATION_COUNT = NAMED_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link themepark.AttractionType <em>Attraction Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.AttractionType
	 * @see themepark.impl.ThemeparkPackageImpl#getAttractionType()
	 * @generated
	 */
	int ATTRACTION_TYPE = 15;

	/**
	 * The meta object id for the '{@link themepark.GateType <em>Gate Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.GateType
	 * @see themepark.impl.ThemeparkPackageImpl#getGateType()
	 * @generated
	 */
	int GATE_TYPE = 16;

	/**
	 * The meta object id for the '{@link themepark.AttractionCategory <em>Attraction Category</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.AttractionCategory
	 * @see themepark.impl.ThemeparkPackageImpl#getAttractionCategory()
	 * @generated
	 */
	int ATTRACTION_CATEGORY = 17;

	/**
	 * The meta object id for the '{@link themepark.Kit <em>Kit</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.Kit
	 * @see themepark.impl.ThemeparkPackageImpl#getKit()
	 * @generated
	 */
	int KIT = 18;

	/**
	 * The meta object id for the '{@link themepark.TransportationCategory <em>Transportation Category</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.TransportationCategory
	 * @see themepark.impl.ThemeparkPackageImpl#getTransportationCategory()
	 * @generated
	 */
	int TRANSPORTATION_CATEGORY = 19;

	/**
	 * The meta object id for the '{@link themepark.TransportationType <em>Transportation Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.TransportationType
	 * @see themepark.impl.ThemeparkPackageImpl#getTransportationType()
	 * @generated
	 */
	int TRANSPORTATION_TYPE = 20;

	/**
	 * The meta object id for the '{@link themepark.ToiletType <em>Toilet Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.ToiletType
	 * @see themepark.impl.ThemeparkPackageImpl#getToiletType()
	 * @generated
	 */
	int TOILET_TYPE = 21;

	/**
	 * The meta object id for the '{@link themepark.RestoType <em>Resto Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see themepark.RestoType
	 * @see themepark.impl.ThemeparkPackageImpl#getRestoType()
	 * @generated
	 */
	int RESTO_TYPE = 22;


	/**
	 * Returns the meta object for class '{@link themepark.ThemePark <em>Theme Park</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Theme Park</em>'.
	 * @see themepark.ThemePark
	 * @generated
	 */
	EClass getThemePark();

	/**
	 * Returns the meta object for the attribute '{@link themepark.ThemePark#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Location</em>'.
	 * @see themepark.ThemePark#getLocation()
	 * @see #getThemePark()
	 * @generated
	 */
	EAttribute getThemePark_Location();

	/**
	 * Returns the meta object for the containment reference list '{@link themepark.ThemePark#getGates <em>Gates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Gates</em>'.
	 * @see themepark.ThemePark#getGates()
	 * @see #getThemePark()
	 * @generated
	 */
	EReference getThemePark_Gates();

	/**
	 * Returns the meta object for the containment reference list '{@link themepark.ThemePark#getThemes <em>Themes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Themes</em>'.
	 * @see themepark.ThemePark#getThemes()
	 * @see #getThemePark()
	 * @generated
	 */
	EReference getThemePark_Themes();

	/**
	 * Returns the meta object for the containment reference list '{@link themepark.ThemePark#getTransportations <em>Transportations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Transportations</em>'.
	 * @see themepark.ThemePark#getTransportations()
	 * @see #getThemePark()
	 * @generated
	 */
	EReference getThemePark_Transportations();

	/**
	 * Returns the meta object for the containment reference list '{@link themepark.ThemePark#getGreenSpaces <em>Green Spaces</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Green Spaces</em>'.
	 * @see themepark.ThemePark#getGreenSpaces()
	 * @see #getThemePark()
	 * @generated
	 */
	EReference getThemePark_GreenSpaces();

	/**
	 * Returns the meta object for class '{@link themepark.Named <em>Named</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Named</em>'.
	 * @see themepark.Named
	 * @generated
	 */
	EClass getNamed();

	/**
	 * Returns the meta object for the attribute '{@link themepark.Named#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see themepark.Named#getName()
	 * @see #getNamed()
	 * @generated
	 */
	EAttribute getNamed_Name();

	/**
	 * Returns the meta object for class '{@link themepark.Theme <em>Theme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Theme</em>'.
	 * @see themepark.Theme
	 * @generated
	 */
	EClass getTheme();

	/**
	 * Returns the meta object for the containment reference list '{@link themepark.Theme#getAttractions <em>Attractions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Attractions</em>'.
	 * @see themepark.Theme#getAttractions()
	 * @see #getTheme()
	 * @generated
	 */
	EReference getTheme_Attractions();

	/**
	 * Returns the meta object for the containment reference list '{@link themepark.Theme#getFacilities <em>Facilities</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Facilities</em>'.
	 * @see themepark.Theme#getFacilities()
	 * @see #getTheme()
	 * @generated
	 */
	EReference getTheme_Facilities();

	/**
	 * Returns the meta object for the reference list '{@link themepark.Theme#getGreenSpaces <em>Green Spaces</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Green Spaces</em>'.
	 * @see themepark.Theme#getGreenSpaces()
	 * @see #getTheme()
	 * @generated
	 */
	EReference getTheme_GreenSpaces();

	/**
	 * Returns the meta object for class '{@link themepark.Gate <em>Gate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Gate</em>'.
	 * @see themepark.Gate
	 * @generated
	 */
	EClass getGate();

	/**
	 * Returns the meta object for the attribute '{@link themepark.Gate#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see themepark.Gate#getType()
	 * @see #getGate()
	 * @generated
	 */
	EAttribute getGate_Type();

	/**
	 * Returns the meta object for class '{@link themepark.Transportation <em>Transportation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transportation</em>'.
	 * @see themepark.Transportation
	 * @generated
	 */
	EClass getTransportation();

	/**
	 * Returns the meta object for the attribute '{@link themepark.Transportation#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see themepark.Transportation#getType()
	 * @see #getTransportation()
	 * @generated
	 */
	EAttribute getTransportation_Type();

	/**
	 * Returns the meta object for the attribute '{@link themepark.Transportation#getCategory <em>Category</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Category</em>'.
	 * @see themepark.Transportation#getCategory()
	 * @see #getTransportation()
	 * @generated
	 */
	EAttribute getTransportation_Category();

	/**
	 * Returns the meta object for the attribute '{@link themepark.Transportation#getDestination <em>Destination</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Destination</em>'.
	 * @see themepark.Transportation#getDestination()
	 * @see #getTransportation()
	 * @generated
	 */
	EAttribute getTransportation_Destination();

	/**
	 * Returns the meta object for class '{@link themepark.Attraction <em>Attraction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attraction</em>'.
	 * @see themepark.Attraction
	 * @generated
	 */
	EClass getAttraction();

	/**
	 * Returns the meta object for the attribute '{@link themepark.Attraction#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see themepark.Attraction#getType()
	 * @see #getAttraction()
	 * @generated
	 */
	EAttribute getAttraction_Type();

	/**
	 * Returns the meta object for the attribute '{@link themepark.Attraction#getCategory <em>Category</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Category</em>'.
	 * @see themepark.Attraction#getCategory()
	 * @see #getAttraction()
	 * @generated
	 */
	EAttribute getAttraction_Category();

	/**
	 * Returns the meta object for the containment reference list '{@link themepark.Attraction#getEquipments <em>Equipments</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Equipments</em>'.
	 * @see themepark.Attraction#getEquipments()
	 * @see #getAttraction()
	 * @generated
	 */
	EReference getAttraction_Equipments();

	/**
	 * Returns the meta object for the attribute '{@link themepark.Attraction#getCapacity <em>Capacity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Capacity</em>'.
	 * @see themepark.Attraction#getCapacity()
	 * @see #getAttraction()
	 * @generated
	 */
	EAttribute getAttraction_Capacity();

	/**
	 * Returns the meta object for class '{@link themepark.Equipment <em>Equipment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Equipment</em>'.
	 * @see themepark.Equipment
	 * @generated
	 */
	EClass getEquipment();

	/**
	 * Returns the meta object for the attribute '{@link themepark.Equipment#getCategory <em>Category</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Category</em>'.
	 * @see themepark.Equipment#getCategory()
	 * @see #getEquipment()
	 * @generated
	 */
	EAttribute getEquipment_Category();

	/**
	 * Returns the meta object for the attribute '{@link themepark.Equipment#getQuantity <em>Quantity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Quantity</em>'.
	 * @see themepark.Equipment#getQuantity()
	 * @see #getEquipment()
	 * @generated
	 */
	EAttribute getEquipment_Quantity();

	/**
	 * Returns the meta object for class '{@link themepark.Facility <em>Facility</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Facility</em>'.
	 * @see themepark.Facility
	 * @generated
	 */
	EClass getFacility();

	/**
	 * Returns the meta object for the attribute '{@link themepark.Facility#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see themepark.Facility#getId()
	 * @see #getFacility()
	 * @generated
	 */
	EAttribute getFacility_Id();

	/**
	 * Returns the meta object for class '{@link themepark.DiningResto <em>Dining Resto</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dining Resto</em>'.
	 * @see themepark.DiningResto
	 * @generated
	 */
	EClass getDiningResto();

	/**
	 * Returns the meta object for the attribute '{@link themepark.DiningResto#getCapacity <em>Capacity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Capacity</em>'.
	 * @see themepark.DiningResto#getCapacity()
	 * @see #getDiningResto()
	 * @generated
	 */
	EAttribute getDiningResto_Capacity();

	/**
	 * Returns the meta object for the attribute '{@link themepark.DiningResto#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see themepark.DiningResto#getType()
	 * @see #getDiningResto()
	 * @generated
	 */
	EAttribute getDiningResto_Type();

	/**
	 * Returns the meta object for the attribute '{@link themepark.DiningResto#getTelephone <em>Telephone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Telephone</em>'.
	 * @see themepark.DiningResto#getTelephone()
	 * @see #getDiningResto()
	 * @generated
	 */
	EAttribute getDiningResto_Telephone();

	/**
	 * Returns the meta object for class '{@link themepark.SouvenirShopping <em>Souvenir Shopping</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Souvenir Shopping</em>'.
	 * @see themepark.SouvenirShopping
	 * @generated
	 */
	EClass getSouvenirShopping();

	/**
	 * Returns the meta object for the attribute '{@link themepark.SouvenirShopping#getTelephone <em>Telephone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Telephone</em>'.
	 * @see themepark.SouvenirShopping#getTelephone()
	 * @see #getSouvenirShopping()
	 * @generated
	 */
	EAttribute getSouvenirShopping_Telephone();

	/**
	 * Returns the meta object for class '{@link themepark.FirstAidEmergency <em>First Aid Emergency</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>First Aid Emergency</em>'.
	 * @see themepark.FirstAidEmergency
	 * @generated
	 */
	EClass getFirstAidEmergency();

	/**
	 * Returns the meta object for the attribute '{@link themepark.FirstAidEmergency#getTelephone <em>Telephone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Telephone</em>'.
	 * @see themepark.FirstAidEmergency#getTelephone()
	 * @see #getFirstAidEmergency()
	 * @generated
	 */
	EAttribute getFirstAidEmergency_Telephone();

	/**
	 * Returns the meta object for class '{@link themepark.BabyCare <em>Baby Care</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Baby Care</em>'.
	 * @see themepark.BabyCare
	 * @generated
	 */
	EClass getBabyCare();

	/**
	 * Returns the meta object for the attribute '{@link themepark.BabyCare#getCapacity <em>Capacity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Capacity</em>'.
	 * @see themepark.BabyCare#getCapacity()
	 * @see #getBabyCare()
	 * @generated
	 */
	EAttribute getBabyCare_Capacity();

	/**
	 * Returns the meta object for class '{@link themepark.InfoCenterPoint <em>Info Center Point</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Info Center Point</em>'.
	 * @see themepark.InfoCenterPoint
	 * @generated
	 */
	EClass getInfoCenterPoint();

	/**
	 * Returns the meta object for the attribute '{@link themepark.InfoCenterPoint#getTelephone <em>Telephone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Telephone</em>'.
	 * @see themepark.InfoCenterPoint#getTelephone()
	 * @see #getInfoCenterPoint()
	 * @generated
	 */
	EAttribute getInfoCenterPoint_Telephone();

	/**
	 * Returns the meta object for class '{@link themepark.Toilet <em>Toilet</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Toilet</em>'.
	 * @see themepark.Toilet
	 * @generated
	 */
	EClass getToilet();

	/**
	 * Returns the meta object for the attribute '{@link themepark.Toilet#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see themepark.Toilet#getType()
	 * @see #getToilet()
	 * @generated
	 */
	EAttribute getToilet_Type();

	/**
	 * Returns the meta object for class '{@link themepark.GreenSpace <em>Green Space</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Green Space</em>'.
	 * @see themepark.GreenSpace
	 * @generated
	 */
	EClass getGreenSpace();

	/**
	 * Returns the meta object for the attribute '{@link themepark.GreenSpace#getArea <em>Area</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Area</em>'.
	 * @see themepark.GreenSpace#getArea()
	 * @see #getGreenSpace()
	 * @generated
	 */
	EAttribute getGreenSpace_Area();

	/**
	 * Returns the meta object for enum '{@link themepark.AttractionType <em>Attraction Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Attraction Type</em>'.
	 * @see themepark.AttractionType
	 * @generated
	 */
	EEnum getAttractionType();

	/**
	 * Returns the meta object for enum '{@link themepark.GateType <em>Gate Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Gate Type</em>'.
	 * @see themepark.GateType
	 * @generated
	 */
	EEnum getGateType();

	/**
	 * Returns the meta object for enum '{@link themepark.AttractionCategory <em>Attraction Category</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Attraction Category</em>'.
	 * @see themepark.AttractionCategory
	 * @generated
	 */
	EEnum getAttractionCategory();

	/**
	 * Returns the meta object for enum '{@link themepark.Kit <em>Kit</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Kit</em>'.
	 * @see themepark.Kit
	 * @generated
	 */
	EEnum getKit();

	/**
	 * Returns the meta object for enum '{@link themepark.TransportationCategory <em>Transportation Category</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Transportation Category</em>'.
	 * @see themepark.TransportationCategory
	 * @generated
	 */
	EEnum getTransportationCategory();

	/**
	 * Returns the meta object for enum '{@link themepark.TransportationType <em>Transportation Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Transportation Type</em>'.
	 * @see themepark.TransportationType
	 * @generated
	 */
	EEnum getTransportationType();

	/**
	 * Returns the meta object for enum '{@link themepark.ToiletType <em>Toilet Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Toilet Type</em>'.
	 * @see themepark.ToiletType
	 * @generated
	 */
	EEnum getToiletType();

	/**
	 * Returns the meta object for enum '{@link themepark.RestoType <em>Resto Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Resto Type</em>'.
	 * @see themepark.RestoType
	 * @generated
	 */
	EEnum getRestoType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ThemeparkFactory getThemeparkFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link themepark.impl.ThemeParkImpl <em>Theme Park</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.impl.ThemeParkImpl
		 * @see themepark.impl.ThemeparkPackageImpl#getThemePark()
		 * @generated
		 */
		EClass THEME_PARK = eINSTANCE.getThemePark();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute THEME_PARK__LOCATION = eINSTANCE.getThemePark_Location();

		/**
		 * The meta object literal for the '<em><b>Gates</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THEME_PARK__GATES = eINSTANCE.getThemePark_Gates();

		/**
		 * The meta object literal for the '<em><b>Themes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THEME_PARK__THEMES = eINSTANCE.getThemePark_Themes();

		/**
		 * The meta object literal for the '<em><b>Transportations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THEME_PARK__TRANSPORTATIONS = eINSTANCE.getThemePark_Transportations();

		/**
		 * The meta object literal for the '<em><b>Green Spaces</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THEME_PARK__GREEN_SPACES = eINSTANCE.getThemePark_GreenSpaces();

		/**
		 * The meta object literal for the '{@link themepark.impl.NamedImpl <em>Named</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.impl.NamedImpl
		 * @see themepark.impl.ThemeparkPackageImpl#getNamed()
		 * @generated
		 */
		EClass NAMED = eINSTANCE.getNamed();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NAMED__NAME = eINSTANCE.getNamed_Name();

		/**
		 * The meta object literal for the '{@link themepark.impl.ThemeImpl <em>Theme</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.impl.ThemeImpl
		 * @see themepark.impl.ThemeparkPackageImpl#getTheme()
		 * @generated
		 */
		EClass THEME = eINSTANCE.getTheme();

		/**
		 * The meta object literal for the '<em><b>Attractions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THEME__ATTRACTIONS = eINSTANCE.getTheme_Attractions();

		/**
		 * The meta object literal for the '<em><b>Facilities</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THEME__FACILITIES = eINSTANCE.getTheme_Facilities();

		/**
		 * The meta object literal for the '<em><b>Green Spaces</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THEME__GREEN_SPACES = eINSTANCE.getTheme_GreenSpaces();

		/**
		 * The meta object literal for the '{@link themepark.impl.GateImpl <em>Gate</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.impl.GateImpl
		 * @see themepark.impl.ThemeparkPackageImpl#getGate()
		 * @generated
		 */
		EClass GATE = eINSTANCE.getGate();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GATE__TYPE = eINSTANCE.getGate_Type();

		/**
		 * The meta object literal for the '{@link themepark.impl.TransportationImpl <em>Transportation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.impl.TransportationImpl
		 * @see themepark.impl.ThemeparkPackageImpl#getTransportation()
		 * @generated
		 */
		EClass TRANSPORTATION = eINSTANCE.getTransportation();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSPORTATION__TYPE = eINSTANCE.getTransportation_Type();

		/**
		 * The meta object literal for the '<em><b>Category</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSPORTATION__CATEGORY = eINSTANCE.getTransportation_Category();

		/**
		 * The meta object literal for the '<em><b>Destination</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSPORTATION__DESTINATION = eINSTANCE.getTransportation_Destination();

		/**
		 * The meta object literal for the '{@link themepark.impl.AttractionImpl <em>Attraction</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.impl.AttractionImpl
		 * @see themepark.impl.ThemeparkPackageImpl#getAttraction()
		 * @generated
		 */
		EClass ATTRACTION = eINSTANCE.getAttraction();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRACTION__TYPE = eINSTANCE.getAttraction_Type();

		/**
		 * The meta object literal for the '<em><b>Category</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRACTION__CATEGORY = eINSTANCE.getAttraction_Category();

		/**
		 * The meta object literal for the '<em><b>Equipments</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTRACTION__EQUIPMENTS = eINSTANCE.getAttraction_Equipments();

		/**
		 * The meta object literal for the '<em><b>Capacity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRACTION__CAPACITY = eINSTANCE.getAttraction_Capacity();

		/**
		 * The meta object literal for the '{@link themepark.impl.EquipmentImpl <em>Equipment</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.impl.EquipmentImpl
		 * @see themepark.impl.ThemeparkPackageImpl#getEquipment()
		 * @generated
		 */
		EClass EQUIPMENT = eINSTANCE.getEquipment();

		/**
		 * The meta object literal for the '<em><b>Category</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EQUIPMENT__CATEGORY = eINSTANCE.getEquipment_Category();

		/**
		 * The meta object literal for the '<em><b>Quantity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EQUIPMENT__QUANTITY = eINSTANCE.getEquipment_Quantity();

		/**
		 * The meta object literal for the '{@link themepark.impl.FacilityImpl <em>Facility</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.impl.FacilityImpl
		 * @see themepark.impl.ThemeparkPackageImpl#getFacility()
		 * @generated
		 */
		EClass FACILITY = eINSTANCE.getFacility();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FACILITY__ID = eINSTANCE.getFacility_Id();

		/**
		 * The meta object literal for the '{@link themepark.impl.DiningRestoImpl <em>Dining Resto</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.impl.DiningRestoImpl
		 * @see themepark.impl.ThemeparkPackageImpl#getDiningResto()
		 * @generated
		 */
		EClass DINING_RESTO = eINSTANCE.getDiningResto();

		/**
		 * The meta object literal for the '<em><b>Capacity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DINING_RESTO__CAPACITY = eINSTANCE.getDiningResto_Capacity();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DINING_RESTO__TYPE = eINSTANCE.getDiningResto_Type();

		/**
		 * The meta object literal for the '<em><b>Telephone</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DINING_RESTO__TELEPHONE = eINSTANCE.getDiningResto_Telephone();

		/**
		 * The meta object literal for the '{@link themepark.impl.SouvenirShoppingImpl <em>Souvenir Shopping</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.impl.SouvenirShoppingImpl
		 * @see themepark.impl.ThemeparkPackageImpl#getSouvenirShopping()
		 * @generated
		 */
		EClass SOUVENIR_SHOPPING = eINSTANCE.getSouvenirShopping();

		/**
		 * The meta object literal for the '<em><b>Telephone</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SOUVENIR_SHOPPING__TELEPHONE = eINSTANCE.getSouvenirShopping_Telephone();

		/**
		 * The meta object literal for the '{@link themepark.impl.FirstAidEmergencyImpl <em>First Aid Emergency</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.impl.FirstAidEmergencyImpl
		 * @see themepark.impl.ThemeparkPackageImpl#getFirstAidEmergency()
		 * @generated
		 */
		EClass FIRST_AID_EMERGENCY = eINSTANCE.getFirstAidEmergency();

		/**
		 * The meta object literal for the '<em><b>Telephone</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIRST_AID_EMERGENCY__TELEPHONE = eINSTANCE.getFirstAidEmergency_Telephone();

		/**
		 * The meta object literal for the '{@link themepark.impl.BabyCareImpl <em>Baby Care</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.impl.BabyCareImpl
		 * @see themepark.impl.ThemeparkPackageImpl#getBabyCare()
		 * @generated
		 */
		EClass BABY_CARE = eINSTANCE.getBabyCare();

		/**
		 * The meta object literal for the '<em><b>Capacity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BABY_CARE__CAPACITY = eINSTANCE.getBabyCare_Capacity();

		/**
		 * The meta object literal for the '{@link themepark.impl.InfoCenterPointImpl <em>Info Center Point</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.impl.InfoCenterPointImpl
		 * @see themepark.impl.ThemeparkPackageImpl#getInfoCenterPoint()
		 * @generated
		 */
		EClass INFO_CENTER_POINT = eINSTANCE.getInfoCenterPoint();

		/**
		 * The meta object literal for the '<em><b>Telephone</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INFO_CENTER_POINT__TELEPHONE = eINSTANCE.getInfoCenterPoint_Telephone();

		/**
		 * The meta object literal for the '{@link themepark.impl.ToiletImpl <em>Toilet</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.impl.ToiletImpl
		 * @see themepark.impl.ThemeparkPackageImpl#getToilet()
		 * @generated
		 */
		EClass TOILET = eINSTANCE.getToilet();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TOILET__TYPE = eINSTANCE.getToilet_Type();

		/**
		 * The meta object literal for the '{@link themepark.impl.GreenSpaceImpl <em>Green Space</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.impl.GreenSpaceImpl
		 * @see themepark.impl.ThemeparkPackageImpl#getGreenSpace()
		 * @generated
		 */
		EClass GREEN_SPACE = eINSTANCE.getGreenSpace();

		/**
		 * The meta object literal for the '<em><b>Area</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GREEN_SPACE__AREA = eINSTANCE.getGreenSpace_Area();

		/**
		 * The meta object literal for the '{@link themepark.AttractionType <em>Attraction Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.AttractionType
		 * @see themepark.impl.ThemeparkPackageImpl#getAttractionType()
		 * @generated
		 */
		EEnum ATTRACTION_TYPE = eINSTANCE.getAttractionType();

		/**
		 * The meta object literal for the '{@link themepark.GateType <em>Gate Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.GateType
		 * @see themepark.impl.ThemeparkPackageImpl#getGateType()
		 * @generated
		 */
		EEnum GATE_TYPE = eINSTANCE.getGateType();

		/**
		 * The meta object literal for the '{@link themepark.AttractionCategory <em>Attraction Category</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.AttractionCategory
		 * @see themepark.impl.ThemeparkPackageImpl#getAttractionCategory()
		 * @generated
		 */
		EEnum ATTRACTION_CATEGORY = eINSTANCE.getAttractionCategory();

		/**
		 * The meta object literal for the '{@link themepark.Kit <em>Kit</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.Kit
		 * @see themepark.impl.ThemeparkPackageImpl#getKit()
		 * @generated
		 */
		EEnum KIT = eINSTANCE.getKit();

		/**
		 * The meta object literal for the '{@link themepark.TransportationCategory <em>Transportation Category</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.TransportationCategory
		 * @see themepark.impl.ThemeparkPackageImpl#getTransportationCategory()
		 * @generated
		 */
		EEnum TRANSPORTATION_CATEGORY = eINSTANCE.getTransportationCategory();

		/**
		 * The meta object literal for the '{@link themepark.TransportationType <em>Transportation Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.TransportationType
		 * @see themepark.impl.ThemeparkPackageImpl#getTransportationType()
		 * @generated
		 */
		EEnum TRANSPORTATION_TYPE = eINSTANCE.getTransportationType();

		/**
		 * The meta object literal for the '{@link themepark.ToiletType <em>Toilet Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.ToiletType
		 * @see themepark.impl.ThemeparkPackageImpl#getToiletType()
		 * @generated
		 */
		EEnum TOILET_TYPE = eINSTANCE.getToiletType();

		/**
		 * The meta object literal for the '{@link themepark.RestoType <em>Resto Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see themepark.RestoType
		 * @see themepark.impl.ThemeparkPackageImpl#getRestoType()
		 * @generated
		 */
		EEnum RESTO_TYPE = eINSTANCE.getRestoType();

	}

} //ThemeparkPackage
