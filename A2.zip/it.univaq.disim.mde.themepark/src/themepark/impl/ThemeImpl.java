/**
 */
package themepark.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import themepark.Attraction;
import themepark.Facility;
import themepark.GreenSpace;
import themepark.Theme;
import themepark.ThemeparkPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Theme</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link themepark.impl.ThemeImpl#getAttractions <em>Attractions</em>}</li>
 *   <li>{@link themepark.impl.ThemeImpl#getFacilities <em>Facilities</em>}</li>
 *   <li>{@link themepark.impl.ThemeImpl#getGreenSpaces <em>Green Spaces</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ThemeImpl extends NamedImpl implements Theme {
	/**
	 * The cached value of the '{@link #getAttractions() <em>Attractions</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttractions()
	 * @generated
	 * @ordered
	 */
	protected EList<Attraction> attractions;

	/**
	 * The cached value of the '{@link #getFacilities() <em>Facilities</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFacilities()
	 * @generated
	 * @ordered
	 */
	protected EList<Facility> facilities;

	/**
	 * The cached value of the '{@link #getGreenSpaces() <em>Green Spaces</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGreenSpaces()
	 * @generated
	 * @ordered
	 */
	protected EList<GreenSpace> greenSpaces;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ThemeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ThemeparkPackage.Literals.THEME;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Attraction> getAttractions() {
		if (attractions == null) {
			attractions = new EObjectContainmentEList<Attraction>(Attraction.class, this, ThemeparkPackage.THEME__ATTRACTIONS);
		}
		return attractions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Facility> getFacilities() {
		if (facilities == null) {
			facilities = new EObjectContainmentEList<Facility>(Facility.class, this, ThemeparkPackage.THEME__FACILITIES);
		}
		return facilities;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<GreenSpace> getGreenSpaces() {
		if (greenSpaces == null) {
			greenSpaces = new EObjectResolvingEList<GreenSpace>(GreenSpace.class, this, ThemeparkPackage.THEME__GREEN_SPACES);
		}
		return greenSpaces;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ThemeparkPackage.THEME__ATTRACTIONS:
				return ((InternalEList<?>)getAttractions()).basicRemove(otherEnd, msgs);
			case ThemeparkPackage.THEME__FACILITIES:
				return ((InternalEList<?>)getFacilities()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ThemeparkPackage.THEME__ATTRACTIONS:
				return getAttractions();
			case ThemeparkPackage.THEME__FACILITIES:
				return getFacilities();
			case ThemeparkPackage.THEME__GREEN_SPACES:
				return getGreenSpaces();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ThemeparkPackage.THEME__ATTRACTIONS:
				getAttractions().clear();
				getAttractions().addAll((Collection<? extends Attraction>)newValue);
				return;
			case ThemeparkPackage.THEME__FACILITIES:
				getFacilities().clear();
				getFacilities().addAll((Collection<? extends Facility>)newValue);
				return;
			case ThemeparkPackage.THEME__GREEN_SPACES:
				getGreenSpaces().clear();
				getGreenSpaces().addAll((Collection<? extends GreenSpace>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ThemeparkPackage.THEME__ATTRACTIONS:
				getAttractions().clear();
				return;
			case ThemeparkPackage.THEME__FACILITIES:
				getFacilities().clear();
				return;
			case ThemeparkPackage.THEME__GREEN_SPACES:
				getGreenSpaces().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ThemeparkPackage.THEME__ATTRACTIONS:
				return attractions != null && !attractions.isEmpty();
			case ThemeparkPackage.THEME__FACILITIES:
				return facilities != null && !facilities.isEmpty();
			case ThemeparkPackage.THEME__GREEN_SPACES:
				return greenSpaces != null && !greenSpaces.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //ThemeImpl
