/**
 */
package themepark.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import themepark.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ThemeparkFactoryImpl extends EFactoryImpl implements ThemeparkFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ThemeparkFactory init() {
		try {
			ThemeparkFactory theThemeparkFactory = (ThemeparkFactory)EPackage.Registry.INSTANCE.getEFactory(ThemeparkPackage.eNS_URI);
			if (theThemeparkFactory != null) {
				return theThemeparkFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ThemeparkFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ThemeparkFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case ThemeparkPackage.THEME_PARK: return createThemePark();
			case ThemeparkPackage.NAMED: return createNamed();
			case ThemeparkPackage.THEME: return createTheme();
			case ThemeparkPackage.GATE: return createGate();
			case ThemeparkPackage.TRANSPORTATION: return createTransportation();
			case ThemeparkPackage.ATTRACTION: return createAttraction();
			case ThemeparkPackage.EQUIPMENT: return createEquipment();
			case ThemeparkPackage.DINING_RESTO: return createDiningResto();
			case ThemeparkPackage.SOUVENIR_SHOPPING: return createSouvenirShopping();
			case ThemeparkPackage.FIRST_AID_EMERGENCY: return createFirstAidEmergency();
			case ThemeparkPackage.BABY_CARE: return createBabyCare();
			case ThemeparkPackage.INFO_CENTER_POINT: return createInfoCenterPoint();
			case ThemeparkPackage.TOILET: return createToilet();
			case ThemeparkPackage.GREEN_SPACE: return createGreenSpace();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case ThemeparkPackage.ATTRACTION_TYPE:
				return createAttractionTypeFromString(eDataType, initialValue);
			case ThemeparkPackage.GATE_TYPE:
				return createGateTypeFromString(eDataType, initialValue);
			case ThemeparkPackage.ATTRACTION_CATEGORY:
				return createAttractionCategoryFromString(eDataType, initialValue);
			case ThemeparkPackage.KIT:
				return createKitFromString(eDataType, initialValue);
			case ThemeparkPackage.TRANSPORTATION_CATEGORY:
				return createTransportationCategoryFromString(eDataType, initialValue);
			case ThemeparkPackage.TRANSPORTATION_TYPE:
				return createTransportationTypeFromString(eDataType, initialValue);
			case ThemeparkPackage.TOILET_TYPE:
				return createToiletTypeFromString(eDataType, initialValue);
			case ThemeparkPackage.RESTO_TYPE:
				return createRestoTypeFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case ThemeparkPackage.ATTRACTION_TYPE:
				return convertAttractionTypeToString(eDataType, instanceValue);
			case ThemeparkPackage.GATE_TYPE:
				return convertGateTypeToString(eDataType, instanceValue);
			case ThemeparkPackage.ATTRACTION_CATEGORY:
				return convertAttractionCategoryToString(eDataType, instanceValue);
			case ThemeparkPackage.KIT:
				return convertKitToString(eDataType, instanceValue);
			case ThemeparkPackage.TRANSPORTATION_CATEGORY:
				return convertTransportationCategoryToString(eDataType, instanceValue);
			case ThemeparkPackage.TRANSPORTATION_TYPE:
				return convertTransportationTypeToString(eDataType, instanceValue);
			case ThemeparkPackage.TOILET_TYPE:
				return convertToiletTypeToString(eDataType, instanceValue);
			case ThemeparkPackage.RESTO_TYPE:
				return convertRestoTypeToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ThemePark createThemePark() {
		ThemeParkImpl themePark = new ThemeParkImpl();
		return themePark;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Named createNamed() {
		NamedImpl named = new NamedImpl();
		return named;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Theme createTheme() {
		ThemeImpl theme = new ThemeImpl();
		return theme;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Gate createGate() {
		GateImpl gate = new GateImpl();
		return gate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Transportation createTransportation() {
		TransportationImpl transportation = new TransportationImpl();
		return transportation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Attraction createAttraction() {
		AttractionImpl attraction = new AttractionImpl();
		return attraction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Equipment createEquipment() {
		EquipmentImpl equipment = new EquipmentImpl();
		return equipment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DiningResto createDiningResto() {
		DiningRestoImpl diningResto = new DiningRestoImpl();
		return diningResto;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SouvenirShopping createSouvenirShopping() {
		SouvenirShoppingImpl souvenirShopping = new SouvenirShoppingImpl();
		return souvenirShopping;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FirstAidEmergency createFirstAidEmergency() {
		FirstAidEmergencyImpl firstAidEmergency = new FirstAidEmergencyImpl();
		return firstAidEmergency;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BabyCare createBabyCare() {
		BabyCareImpl babyCare = new BabyCareImpl();
		return babyCare;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InfoCenterPoint createInfoCenterPoint() {
		InfoCenterPointImpl infoCenterPoint = new InfoCenterPointImpl();
		return infoCenterPoint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Toilet createToilet() {
		ToiletImpl toilet = new ToiletImpl();
		return toilet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GreenSpace createGreenSpace() {
		GreenSpaceImpl greenSpace = new GreenSpaceImpl();
		return greenSpace;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttractionType createAttractionTypeFromString(EDataType eDataType, String initialValue) {
		AttractionType result = AttractionType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertAttractionTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GateType createGateTypeFromString(EDataType eDataType, String initialValue) {
		GateType result = GateType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertGateTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttractionCategory createAttractionCategoryFromString(EDataType eDataType, String initialValue) {
		AttractionCategory result = AttractionCategory.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertAttractionCategoryToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Kit createKitFromString(EDataType eDataType, String initialValue) {
		Kit result = Kit.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertKitToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TransportationCategory createTransportationCategoryFromString(EDataType eDataType, String initialValue) {
		TransportationCategory result = TransportationCategory.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTransportationCategoryToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TransportationType createTransportationTypeFromString(EDataType eDataType, String initialValue) {
		TransportationType result = TransportationType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTransportationTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ToiletType createToiletTypeFromString(EDataType eDataType, String initialValue) {
		ToiletType result = ToiletType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertToiletTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RestoType createRestoTypeFromString(EDataType eDataType, String initialValue) {
		RestoType result = RestoType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertRestoTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ThemeparkPackage getThemeparkPackage() {
		return (ThemeparkPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static ThemeparkPackage getPackage() {
		return ThemeparkPackage.eINSTANCE;
	}

} //ThemeparkFactoryImpl
