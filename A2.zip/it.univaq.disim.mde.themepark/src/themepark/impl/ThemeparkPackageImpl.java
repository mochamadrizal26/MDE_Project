/**
 */
package themepark.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import themepark.Attraction;
import themepark.AttractionCategory;
import themepark.AttractionType;
import themepark.BabyCare;
import themepark.DiningResto;
import themepark.Equipment;
import themepark.Facility;
import themepark.FirstAidEmergency;
import themepark.Gate;
import themepark.GateType;
import themepark.GreenSpace;
import themepark.InfoCenterPoint;
import themepark.Kit;
import themepark.Named;
import themepark.RestoType;
import themepark.SouvenirShopping;
import themepark.Theme;
import themepark.ThemePark;
import themepark.ThemeparkFactory;
import themepark.ThemeparkPackage;
import themepark.Toilet;
import themepark.ToiletType;
import themepark.Transportation;
import themepark.TransportationCategory;
import themepark.TransportationType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ThemeparkPackageImpl extends EPackageImpl implements ThemeparkPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass themeParkEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass namedEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass themeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass gateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass transportationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attractionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass equipmentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass facilityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass diningRestoEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass souvenirShoppingEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass firstAidEmergencyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass babyCareEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass infoCenterPointEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass toiletEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass greenSpaceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum attractionTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum gateTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum attractionCategoryEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum kitEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum transportationCategoryEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum transportationTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum toiletTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum restoTypeEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see themepark.ThemeparkPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private ThemeparkPackageImpl() {
		super(eNS_URI, ThemeparkFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link ThemeparkPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static ThemeparkPackage init() {
		if (isInited) return (ThemeparkPackage)EPackage.Registry.INSTANCE.getEPackage(ThemeparkPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredThemeparkPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		ThemeparkPackageImpl theThemeparkPackage = registeredThemeparkPackage instanceof ThemeparkPackageImpl ? (ThemeparkPackageImpl)registeredThemeparkPackage : new ThemeparkPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theThemeparkPackage.createPackageContents();

		// Initialize created meta-data
		theThemeparkPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theThemeparkPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(ThemeparkPackage.eNS_URI, theThemeparkPackage);
		return theThemeparkPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getThemePark() {
		return themeParkEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getThemePark_Location() {
		return (EAttribute)themeParkEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getThemePark_Gates() {
		return (EReference)themeParkEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getThemePark_Themes() {
		return (EReference)themeParkEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getThemePark_Transportations() {
		return (EReference)themeParkEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getThemePark_GreenSpaces() {
		return (EReference)themeParkEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNamed() {
		return namedEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNamed_Name() {
		return (EAttribute)namedEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTheme() {
		return themeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTheme_Attractions() {
		return (EReference)themeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTheme_Facilities() {
		return (EReference)themeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTheme_GreenSpaces() {
		return (EReference)themeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getGate() {
		return gateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGate_Type() {
		return (EAttribute)gateEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTransportation() {
		return transportationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransportation_Type() {
		return (EAttribute)transportationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransportation_Category() {
		return (EAttribute)transportationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransportation_Destination() {
		return (EAttribute)transportationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAttraction() {
		return attractionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttraction_Type() {
		return (EAttribute)attractionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttraction_Category() {
		return (EAttribute)attractionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAttraction_Equipments() {
		return (EReference)attractionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttraction_Capacity() {
		return (EAttribute)attractionEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEquipment() {
		return equipmentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEquipment_Category() {
		return (EAttribute)equipmentEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEquipment_Quantity() {
		return (EAttribute)equipmentEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFacility() {
		return facilityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFacility_Id() {
		return (EAttribute)facilityEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDiningResto() {
		return diningRestoEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDiningResto_Capacity() {
		return (EAttribute)diningRestoEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDiningResto_Type() {
		return (EAttribute)diningRestoEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDiningResto_Telephone() {
		return (EAttribute)diningRestoEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSouvenirShopping() {
		return souvenirShoppingEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSouvenirShopping_Telephone() {
		return (EAttribute)souvenirShoppingEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFirstAidEmergency() {
		return firstAidEmergencyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFirstAidEmergency_Telephone() {
		return (EAttribute)firstAidEmergencyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBabyCare() {
		return babyCareEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBabyCare_Capacity() {
		return (EAttribute)babyCareEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInfoCenterPoint() {
		return infoCenterPointEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInfoCenterPoint_Telephone() {
		return (EAttribute)infoCenterPointEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getToilet() {
		return toiletEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getToilet_Type() {
		return (EAttribute)toiletEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getGreenSpace() {
		return greenSpaceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGreenSpace_Area() {
		return (EAttribute)greenSpaceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getAttractionType() {
		return attractionTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getGateType() {
		return gateTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getAttractionCategory() {
		return attractionCategoryEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getKit() {
		return kitEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getTransportationCategory() {
		return transportationCategoryEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getTransportationType() {
		return transportationTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getToiletType() {
		return toiletTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getRestoType() {
		return restoTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ThemeparkFactory getThemeparkFactory() {
		return (ThemeparkFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		themeParkEClass = createEClass(THEME_PARK);
		createEAttribute(themeParkEClass, THEME_PARK__LOCATION);
		createEReference(themeParkEClass, THEME_PARK__GATES);
		createEReference(themeParkEClass, THEME_PARK__THEMES);
		createEReference(themeParkEClass, THEME_PARK__TRANSPORTATIONS);
		createEReference(themeParkEClass, THEME_PARK__GREEN_SPACES);

		namedEClass = createEClass(NAMED);
		createEAttribute(namedEClass, NAMED__NAME);

		themeEClass = createEClass(THEME);
		createEReference(themeEClass, THEME__ATTRACTIONS);
		createEReference(themeEClass, THEME__FACILITIES);
		createEReference(themeEClass, THEME__GREEN_SPACES);

		gateEClass = createEClass(GATE);
		createEAttribute(gateEClass, GATE__TYPE);

		transportationEClass = createEClass(TRANSPORTATION);
		createEAttribute(transportationEClass, TRANSPORTATION__TYPE);
		createEAttribute(transportationEClass, TRANSPORTATION__CATEGORY);
		createEAttribute(transportationEClass, TRANSPORTATION__DESTINATION);

		attractionEClass = createEClass(ATTRACTION);
		createEAttribute(attractionEClass, ATTRACTION__TYPE);
		createEAttribute(attractionEClass, ATTRACTION__CATEGORY);
		createEReference(attractionEClass, ATTRACTION__EQUIPMENTS);
		createEAttribute(attractionEClass, ATTRACTION__CAPACITY);

		equipmentEClass = createEClass(EQUIPMENT);
		createEAttribute(equipmentEClass, EQUIPMENT__CATEGORY);
		createEAttribute(equipmentEClass, EQUIPMENT__QUANTITY);

		facilityEClass = createEClass(FACILITY);
		createEAttribute(facilityEClass, FACILITY__ID);

		diningRestoEClass = createEClass(DINING_RESTO);
		createEAttribute(diningRestoEClass, DINING_RESTO__CAPACITY);
		createEAttribute(diningRestoEClass, DINING_RESTO__TYPE);
		createEAttribute(diningRestoEClass, DINING_RESTO__TELEPHONE);

		souvenirShoppingEClass = createEClass(SOUVENIR_SHOPPING);
		createEAttribute(souvenirShoppingEClass, SOUVENIR_SHOPPING__TELEPHONE);

		firstAidEmergencyEClass = createEClass(FIRST_AID_EMERGENCY);
		createEAttribute(firstAidEmergencyEClass, FIRST_AID_EMERGENCY__TELEPHONE);

		babyCareEClass = createEClass(BABY_CARE);
		createEAttribute(babyCareEClass, BABY_CARE__CAPACITY);

		infoCenterPointEClass = createEClass(INFO_CENTER_POINT);
		createEAttribute(infoCenterPointEClass, INFO_CENTER_POINT__TELEPHONE);

		toiletEClass = createEClass(TOILET);
		createEAttribute(toiletEClass, TOILET__TYPE);

		greenSpaceEClass = createEClass(GREEN_SPACE);
		createEAttribute(greenSpaceEClass, GREEN_SPACE__AREA);

		// Create enums
		attractionTypeEEnum = createEEnum(ATTRACTION_TYPE);
		gateTypeEEnum = createEEnum(GATE_TYPE);
		attractionCategoryEEnum = createEEnum(ATTRACTION_CATEGORY);
		kitEEnum = createEEnum(KIT);
		transportationCategoryEEnum = createEEnum(TRANSPORTATION_CATEGORY);
		transportationTypeEEnum = createEEnum(TRANSPORTATION_TYPE);
		toiletTypeEEnum = createEEnum(TOILET_TYPE);
		restoTypeEEnum = createEEnum(RESTO_TYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		themeParkEClass.getESuperTypes().add(this.getNamed());
		themeEClass.getESuperTypes().add(this.getNamed());
		gateEClass.getESuperTypes().add(this.getNamed());
		transportationEClass.getESuperTypes().add(this.getNamed());
		attractionEClass.getESuperTypes().add(this.getNamed());
		equipmentEClass.getESuperTypes().add(this.getNamed());
		facilityEClass.getESuperTypes().add(this.getNamed());
		diningRestoEClass.getESuperTypes().add(this.getFacility());
		souvenirShoppingEClass.getESuperTypes().add(this.getFacility());
		firstAidEmergencyEClass.getESuperTypes().add(this.getFacility());
		babyCareEClass.getESuperTypes().add(this.getFacility());
		infoCenterPointEClass.getESuperTypes().add(this.getFacility());
		toiletEClass.getESuperTypes().add(this.getFacility());
		greenSpaceEClass.getESuperTypes().add(this.getNamed());

		// Initialize classes, features, and operations; add parameters
		initEClass(themeParkEClass, ThemePark.class, "ThemePark", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getThemePark_Location(), ecorePackage.getEString(), "location", null, 0, 1, ThemePark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getThemePark_Gates(), this.getGate(), null, "gates", null, 1, -1, ThemePark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getThemePark_Themes(), this.getTheme(), null, "themes", null, 1, -1, ThemePark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getThemePark_Transportations(), this.getTransportation(), null, "transportations", null, 1, -1, ThemePark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getThemePark_GreenSpaces(), this.getGreenSpace(), null, "greenSpaces", null, 0, -1, ThemePark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(namedEClass, Named.class, "Named", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getNamed_Name(), ecorePackage.getEString(), "name", null, 0, 1, Named.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(themeEClass, Theme.class, "Theme", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTheme_Attractions(), this.getAttraction(), null, "attractions", null, 1, -1, Theme.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTheme_Facilities(), this.getFacility(), null, "facilities", null, 1, -1, Theme.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTheme_GreenSpaces(), this.getGreenSpace(), null, "greenSpaces", null, 0, -1, Theme.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(gateEClass, Gate.class, "Gate", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getGate_Type(), this.getGateType(), "type", null, 0, 1, Gate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(transportationEClass, Transportation.class, "Transportation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTransportation_Type(), this.getTransportationType(), "type", null, 0, 1, Transportation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransportation_Category(), this.getTransportationCategory(), "category", null, 0, 1, Transportation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransportation_Destination(), ecorePackage.getEString(), "destination", null, 0, 1, Transportation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(attractionEClass, Attraction.class, "Attraction", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAttraction_Type(), this.getAttractionType(), "type", null, 0, 1, Attraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAttraction_Category(), this.getAttractionCategory(), "category", null, 0, 1, Attraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAttraction_Equipments(), this.getEquipment(), null, "equipments", null, 1, -1, Attraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAttraction_Capacity(), ecorePackage.getEInt(), "capacity", null, 0, 1, Attraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(equipmentEClass, Equipment.class, "Equipment", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getEquipment_Category(), this.getKit(), "category", null, 0, 1, Equipment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getEquipment_Quantity(), ecorePackage.getEInt(), "quantity", null, 0, 1, Equipment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(facilityEClass, Facility.class, "Facility", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFacility_Id(), ecorePackage.getEString(), "id", null, 0, 1, Facility.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(diningRestoEClass, DiningResto.class, "DiningResto", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDiningResto_Capacity(), ecorePackage.getEInt(), "capacity", null, 0, 1, DiningResto.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDiningResto_Type(), this.getRestoType(), "type", null, 0, 1, DiningResto.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDiningResto_Telephone(), ecorePackage.getEString(), "telephone", null, 0, 1, DiningResto.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(souvenirShoppingEClass, SouvenirShopping.class, "SouvenirShopping", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSouvenirShopping_Telephone(), ecorePackage.getEString(), "telephone", null, 0, 1, SouvenirShopping.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(firstAidEmergencyEClass, FirstAidEmergency.class, "FirstAidEmergency", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFirstAidEmergency_Telephone(), ecorePackage.getEString(), "telephone", null, 0, 1, FirstAidEmergency.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(babyCareEClass, BabyCare.class, "BabyCare", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getBabyCare_Capacity(), ecorePackage.getEInt(), "capacity", null, 0, 1, BabyCare.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(infoCenterPointEClass, InfoCenterPoint.class, "InfoCenterPoint", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getInfoCenterPoint_Telephone(), ecorePackage.getEString(), "telephone", null, 0, 1, InfoCenterPoint.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(toiletEClass, Toilet.class, "Toilet", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getToilet_Type(), this.getToiletType(), "type", null, 0, 1, Toilet.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(greenSpaceEClass, GreenSpace.class, "GreenSpace", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getGreenSpace_Area(), ecorePackage.getEFloat(), "area", null, 0, 1, GreenSpace.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(attractionTypeEEnum, AttractionType.class, "AttractionType");
		addEEnumLiteral(attractionTypeEEnum, AttractionType.GENERAL);
		addEEnumLiteral(attractionTypeEEnum, AttractionType.WATER);
		addEEnumLiteral(attractionTypeEEnum, AttractionType.INDOOR);
		addEEnumLiteral(attractionTypeEEnum, AttractionType.EXTREME);

		initEEnum(gateTypeEEnum, GateType.class, "GateType");
		addEEnumLiteral(gateTypeEEnum, GateType.ENTRANCE);
		addEEnumLiteral(gateTypeEEnum, GateType.EXIT);

		initEEnum(attractionCategoryEEnum, AttractionCategory.class, "AttractionCategory");
		addEEnumLiteral(attractionCategoryEEnum, AttractionCategory.GENERAL);
		addEEnumLiteral(attractionCategoryEEnum, AttractionCategory.CHILDREN);
		addEEnumLiteral(attractionCategoryEEnum, AttractionCategory.ADULT);

		initEEnum(kitEEnum, Kit.class, "Kit");
		addEEnumLiteral(kitEEnum, Kit.GENERAL);
		addEEnumLiteral(kitEEnum, Kit.SAFETY);
		addEEnumLiteral(kitEEnum, Kit.SECURITY);

		initEEnum(transportationCategoryEEnum, TransportationCategory.class, "TransportationCategory");
		addEEnumLiteral(transportationCategoryEEnum, TransportationCategory.LAND);
		addEEnumLiteral(transportationCategoryEEnum, TransportationCategory.WATER);
		addEEnumLiteral(transportationCategoryEEnum, TransportationCategory.AIR);

		initEEnum(transportationTypeEEnum, TransportationType.class, "TransportationType");
		addEEnumLiteral(transportationTypeEEnum, TransportationType.PUBLIC);
		addEEnumLiteral(transportationTypeEEnum, TransportationType.PRIVATE);

		initEEnum(toiletTypeEEnum, ToiletType.class, "ToiletType");
		addEEnumLiteral(toiletTypeEEnum, ToiletType.GENERAL);
		addEEnumLiteral(toiletTypeEEnum, ToiletType.MALE);
		addEEnumLiteral(toiletTypeEEnum, ToiletType.FEMALE);

		initEEnum(restoTypeEEnum, RestoType.class, "RestoType");
		addEEnumLiteral(restoTypeEEnum, RestoType.GENERAL);
		addEEnumLiteral(restoTypeEEnum, RestoType.WESTERN);
		addEEnumLiteral(restoTypeEEnum, RestoType.CHINESE);
		addEEnumLiteral(restoTypeEEnum, RestoType.INDIAN);

		// Create resource
		createResource(eNS_URI);
	}

} //ThemeparkPackageImpl
