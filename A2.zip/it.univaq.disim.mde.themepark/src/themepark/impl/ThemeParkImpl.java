/**
 */
package themepark.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import themepark.Gate;
import themepark.GreenSpace;
import themepark.Theme;
import themepark.ThemePark;
import themepark.ThemeparkPackage;
import themepark.Transportation;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Theme Park</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link themepark.impl.ThemeParkImpl#getLocation <em>Location</em>}</li>
 *   <li>{@link themepark.impl.ThemeParkImpl#getGates <em>Gates</em>}</li>
 *   <li>{@link themepark.impl.ThemeParkImpl#getThemes <em>Themes</em>}</li>
 *   <li>{@link themepark.impl.ThemeParkImpl#getTransportations <em>Transportations</em>}</li>
 *   <li>{@link themepark.impl.ThemeParkImpl#getGreenSpaces <em>Green Spaces</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ThemeParkImpl extends NamedImpl implements ThemePark {
	/**
	 * The default value of the '{@link #getLocation() <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation()
	 * @generated
	 * @ordered
	 */
	protected static final String LOCATION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLocation() <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation()
	 * @generated
	 * @ordered
	 */
	protected String location = LOCATION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getGates() <em>Gates</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGates()
	 * @generated
	 * @ordered
	 */
	protected EList<Gate> gates;

	/**
	 * The cached value of the '{@link #getThemes() <em>Themes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThemes()
	 * @generated
	 * @ordered
	 */
	protected EList<Theme> themes;

	/**
	 * The cached value of the '{@link #getTransportations() <em>Transportations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransportations()
	 * @generated
	 * @ordered
	 */
	protected EList<Transportation> transportations;

	/**
	 * The cached value of the '{@link #getGreenSpaces() <em>Green Spaces</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGreenSpaces()
	 * @generated
	 * @ordered
	 */
	protected EList<GreenSpace> greenSpaces;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ThemeParkImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ThemeparkPackage.Literals.THEME_PARK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLocation(String newLocation) {
		String oldLocation = location;
		location = newLocation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ThemeparkPackage.THEME_PARK__LOCATION, oldLocation, location));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Gate> getGates() {
		if (gates == null) {
			gates = new EObjectContainmentEList<Gate>(Gate.class, this, ThemeparkPackage.THEME_PARK__GATES);
		}
		return gates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Theme> getThemes() {
		if (themes == null) {
			themes = new EObjectContainmentEList<Theme>(Theme.class, this, ThemeparkPackage.THEME_PARK__THEMES);
		}
		return themes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Transportation> getTransportations() {
		if (transportations == null) {
			transportations = new EObjectContainmentEList<Transportation>(Transportation.class, this, ThemeparkPackage.THEME_PARK__TRANSPORTATIONS);
		}
		return transportations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<GreenSpace> getGreenSpaces() {
		if (greenSpaces == null) {
			greenSpaces = new EObjectContainmentEList<GreenSpace>(GreenSpace.class, this, ThemeparkPackage.THEME_PARK__GREEN_SPACES);
		}
		return greenSpaces;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ThemeparkPackage.THEME_PARK__GATES:
				return ((InternalEList<?>)getGates()).basicRemove(otherEnd, msgs);
			case ThemeparkPackage.THEME_PARK__THEMES:
				return ((InternalEList<?>)getThemes()).basicRemove(otherEnd, msgs);
			case ThemeparkPackage.THEME_PARK__TRANSPORTATIONS:
				return ((InternalEList<?>)getTransportations()).basicRemove(otherEnd, msgs);
			case ThemeparkPackage.THEME_PARK__GREEN_SPACES:
				return ((InternalEList<?>)getGreenSpaces()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ThemeparkPackage.THEME_PARK__LOCATION:
				return getLocation();
			case ThemeparkPackage.THEME_PARK__GATES:
				return getGates();
			case ThemeparkPackage.THEME_PARK__THEMES:
				return getThemes();
			case ThemeparkPackage.THEME_PARK__TRANSPORTATIONS:
				return getTransportations();
			case ThemeparkPackage.THEME_PARK__GREEN_SPACES:
				return getGreenSpaces();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ThemeparkPackage.THEME_PARK__LOCATION:
				setLocation((String)newValue);
				return;
			case ThemeparkPackage.THEME_PARK__GATES:
				getGates().clear();
				getGates().addAll((Collection<? extends Gate>)newValue);
				return;
			case ThemeparkPackage.THEME_PARK__THEMES:
				getThemes().clear();
				getThemes().addAll((Collection<? extends Theme>)newValue);
				return;
			case ThemeparkPackage.THEME_PARK__TRANSPORTATIONS:
				getTransportations().clear();
				getTransportations().addAll((Collection<? extends Transportation>)newValue);
				return;
			case ThemeparkPackage.THEME_PARK__GREEN_SPACES:
				getGreenSpaces().clear();
				getGreenSpaces().addAll((Collection<? extends GreenSpace>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ThemeparkPackage.THEME_PARK__LOCATION:
				setLocation(LOCATION_EDEFAULT);
				return;
			case ThemeparkPackage.THEME_PARK__GATES:
				getGates().clear();
				return;
			case ThemeparkPackage.THEME_PARK__THEMES:
				getThemes().clear();
				return;
			case ThemeparkPackage.THEME_PARK__TRANSPORTATIONS:
				getTransportations().clear();
				return;
			case ThemeparkPackage.THEME_PARK__GREEN_SPACES:
				getGreenSpaces().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ThemeparkPackage.THEME_PARK__LOCATION:
				return LOCATION_EDEFAULT == null ? location != null : !LOCATION_EDEFAULT.equals(location);
			case ThemeparkPackage.THEME_PARK__GATES:
				return gates != null && !gates.isEmpty();
			case ThemeparkPackage.THEME_PARK__THEMES:
				return themes != null && !themes.isEmpty();
			case ThemeparkPackage.THEME_PARK__TRANSPORTATIONS:
				return transportations != null && !transportations.isEmpty();
			case ThemeparkPackage.THEME_PARK__GREEN_SPACES:
				return greenSpaces != null && !greenSpaces.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (location: ");
		result.append(location);
		result.append(')');
		return result.toString();
	}

} //ThemeParkImpl
