/**
 */
package themepark;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Toilet</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link themepark.Toilet#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see themepark.ThemeparkPackage#getToilet()
 * @model
 * @generated
 */
public interface Toilet extends Facility {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link themepark.ToiletType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see themepark.ToiletType
	 * @see #setType(ToiletType)
	 * @see themepark.ThemeparkPackage#getToilet_Type()
	 * @model
	 * @generated
	 */
	ToiletType getType();

	/**
	 * Sets the value of the '{@link themepark.Toilet#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see themepark.ToiletType
	 * @see #getType()
	 * @generated
	 */
	void setType(ToiletType value);

} // Toilet
