/**
 */
package themepark;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>First Aid Emergency</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link themepark.FirstAidEmergency#getTelephone <em>Telephone</em>}</li>
 * </ul>
 *
 * @see themepark.ThemeparkPackage#getFirstAidEmergency()
 * @model
 * @generated
 */
public interface FirstAidEmergency extends Facility {

	/**
	 * Returns the value of the '<em><b>Telephone</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Telephone</em>' attribute.
	 * @see #setTelephone(String)
	 * @see themepark.ThemeparkPackage#getFirstAidEmergency_Telephone()
	 * @model
	 * @generated
	 */
	String getTelephone();

	/**
	 * Sets the value of the '{@link themepark.FirstAidEmergency#getTelephone <em>Telephone</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Telephone</em>' attribute.
	 * @see #getTelephone()
	 * @generated
	 */
	void setTelephone(String value);
} // FirstAidEmergency
