/**
 */
package themepark;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transportation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link themepark.Transportation#getType <em>Type</em>}</li>
 *   <li>{@link themepark.Transportation#getCategory <em>Category</em>}</li>
 *   <li>{@link themepark.Transportation#getDestination <em>Destination</em>}</li>
 * </ul>
 *
 * @see themepark.ThemeparkPackage#getTransportation()
 * @model
 * @generated
 */
public interface Transportation extends Named {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link themepark.TransportationType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see themepark.TransportationType
	 * @see #setType(TransportationType)
	 * @see themepark.ThemeparkPackage#getTransportation_Type()
	 * @model
	 * @generated
	 */
	TransportationType getType();

	/**
	 * Sets the value of the '{@link themepark.Transportation#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see themepark.TransportationType
	 * @see #getType()
	 * @generated
	 */
	void setType(TransportationType value);

	/**
	 * Returns the value of the '<em><b>Category</b></em>' attribute.
	 * The literals are from the enumeration {@link themepark.TransportationCategory}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Category</em>' attribute.
	 * @see themepark.TransportationCategory
	 * @see #setCategory(TransportationCategory)
	 * @see themepark.ThemeparkPackage#getTransportation_Category()
	 * @model
	 * @generated
	 */
	TransportationCategory getCategory();

	/**
	 * Sets the value of the '{@link themepark.Transportation#getCategory <em>Category</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Category</em>' attribute.
	 * @see themepark.TransportationCategory
	 * @see #getCategory()
	 * @generated
	 */
	void setCategory(TransportationCategory value);

	/**
	 * Returns the value of the '<em><b>Destination</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Destination</em>' attribute.
	 * @see #setDestination(String)
	 * @see themepark.ThemeparkPackage#getTransportation_Destination()
	 * @model
	 * @generated
	 */
	String getDestination();

	/**
	 * Sets the value of the '{@link themepark.Transportation#getDestination <em>Destination</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Destination</em>' attribute.
	 * @see #getDestination()
	 * @generated
	 */
	void setDestination(String value);

} // Transportation
