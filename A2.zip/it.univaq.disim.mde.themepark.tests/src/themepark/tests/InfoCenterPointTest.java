/**
 */
package themepark.tests;

import junit.textui.TestRunner;

import themepark.InfoCenterPoint;
import themepark.ThemeparkFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Info Center Point</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class InfoCenterPointTest extends FacilityTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(InfoCenterPointTest.class);
	}

	/**
	 * Constructs a new Info Center Point test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InfoCenterPointTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Info Center Point test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected InfoCenterPoint getFixture() {
		return (InfoCenterPoint)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(ThemeparkFactory.eINSTANCE.createInfoCenterPoint());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //InfoCenterPointTest
