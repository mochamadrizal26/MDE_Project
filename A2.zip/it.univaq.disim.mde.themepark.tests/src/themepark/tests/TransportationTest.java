/**
 */
package themepark.tests;

import junit.textui.TestRunner;

import themepark.ThemeparkFactory;
import themepark.Transportation;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Transportation</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class TransportationTest extends NamedTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(TransportationTest.class);
	}

	/**
	 * Constructs a new Transportation test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TransportationTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Transportation test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected Transportation getFixture() {
		return (Transportation)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(ThemeparkFactory.eINSTANCE.createTransportation());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //TransportationTest
