/**
 */
package themepark.tests;

import themepark.Facility;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Facility</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class FacilityTest extends NamedTest {

	/**
	 * Constructs a new Facility test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FacilityTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Facility test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected Facility getFixture() {
		return (Facility)fixture;
	}

} //FacilityTest
