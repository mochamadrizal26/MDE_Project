/**
 */
package themepark.tests;

import junit.textui.TestRunner;

import themepark.Gate;
import themepark.ThemeparkFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Gate</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class GateTest extends NamedTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(GateTest.class);
	}

	/**
	 * Constructs a new Gate test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GateTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Gate test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected Gate getFixture() {
		return (Gate)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(ThemeparkFactory.eINSTANCE.createGate());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //GateTest
