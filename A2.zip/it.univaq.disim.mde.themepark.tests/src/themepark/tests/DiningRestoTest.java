/**
 */
package themepark.tests;

import junit.textui.TestRunner;

import themepark.DiningResto;
import themepark.ThemeparkFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Dining Resto</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class DiningRestoTest extends FacilityTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(DiningRestoTest.class);
	}

	/**
	 * Constructs a new Dining Resto test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DiningRestoTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Dining Resto test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected DiningResto getFixture() {
		return (DiningResto)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(ThemeparkFactory.eINSTANCE.createDiningResto());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //DiningRestoTest
