/**
 */
package themepark.tests;

import junit.textui.TestRunner;

import themepark.ThemeparkFactory;
import themepark.Toilet;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Toilet</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class ToiletTest extends FacilityTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(ToiletTest.class);
	}

	/**
	 * Constructs a new Toilet test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ToiletTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Toilet test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected Toilet getFixture() {
		return (Toilet)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(ThemeparkFactory.eINSTANCE.createToilet());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //ToiletTest
