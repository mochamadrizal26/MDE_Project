/**
 */
package themepark.tests;

import junit.textui.TestRunner;

import themepark.SouvenirShopping;
import themepark.ThemeparkFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Souvenir Shopping</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class SouvenirShoppingTest extends FacilityTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(SouvenirShoppingTest.class);
	}

	/**
	 * Constructs a new Souvenir Shopping test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SouvenirShoppingTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Souvenir Shopping test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected SouvenirShopping getFixture() {
		return (SouvenirShopping)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(ThemeparkFactory.eINSTANCE.createSouvenirShopping());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //SouvenirShoppingTest
