/**
 */
package themepark.tests;

import junit.textui.TestRunner;

import themepark.FirstAidEmergency;
import themepark.ThemeparkFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>First Aid Emergency</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class FirstAidEmergencyTest extends FacilityTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(FirstAidEmergencyTest.class);
	}

	/**
	 * Constructs a new First Aid Emergency test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FirstAidEmergencyTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this First Aid Emergency test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected FirstAidEmergency getFixture() {
		return (FirstAidEmergency)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(ThemeparkFactory.eINSTANCE.createFirstAidEmergency());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //FirstAidEmergencyTest
